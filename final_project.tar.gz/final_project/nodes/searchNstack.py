#!/usr/bin/env python3
#Try using go to object, storing pose and then using go to currPose
#if that fails, try to go pose with the initial cube as the center

import asyncio

import cozmo
from cozmo.util import degrees, distance_mm, Pose


def search_and_stack(robot: cozmo.robot.Robot):

    originPose = robot.pose
    h = 0
    numloop = 0
    bra = 0
    while numloop < 2:
        lookaround = robot.start_behavior(cozmo.behavior.BehaviorTypes.LookAroundInPlace)
        cubes = robot.world.wait_until_observe_num_objects(num=3, timeout=20)
        lookaround.stop()

        if len(cubes) < 3:
            print("Error: need 3 Cubes but only found", len(cubes), "Cube(s)")
        else:
            #pick up a cube
            current_action = robot.pickup_object(cubes[0], num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Pickup Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.go_to_pose(Pose(originPose.position.x-200+h, originPose.position.y, originPose.position.z, angle_z=degrees(0)), relative_to_robot=False, num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Go to pose failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.place_object_on_ground_here(cubes[0])
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Third Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            '''current_action = robot.go_to_object(cubes[0], distance_mm(0.0), num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Pickup Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            currPose = robot.pose
            newPose = currPose.position.x - 50'''

            currPose = robot.pose
            current_action = robot.pickup_object(cubes[1], num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Pickup Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            '''current_action = robot.go_to_pose(currPose, relative_to_robot=False,num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Go to pose failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return'''
            #currPose.position.x, currPose.position.y-60, currPose.position.z, angle_z=degrees(0)
            current_action = robot.go_to_pose(Pose(originPose.position.x-200+h, originPose.position.y-75, originPose.position.z, angle_z=degrees(0)), relative_to_robot=False, num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Adjustment failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.place_object_on_ground_here(cubes[1])
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Third Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            '''current_action = robot.go_to_object(cubes[1], distance_mm(30.0), num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Pickup Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.go_to_pose(Pose(0, 100, 0, angle_z=degrees(0)), relative_to_robot=True, num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Adjustment failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            currPose = robot.pose
            newPose = currPose.position.x - 50'''

            current_action = robot.pickup_object(cubes[2], num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Pickup Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return


            '''current_action = robot.go_to_pose(currPose, relative_to_robot=False,num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Go to pose failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return'''

            current_action = robot.go_to_pose(Pose(originPose.position.x-200+h, originPose.position.y-150, originPose.position.z, angle_z=degrees(0)), relative_to_robot=False, num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Adjustment failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.place_object_on_ground_here(cubes[2])
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Third Cube failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            current_action = robot.go_to_pose(Pose(originPose.position.x, originPose.position.y, originPose.position.z, angle_z=degrees(0)), relative_to_robot=False, num_retries=3)
            current_action.wait_for_completed()
            if current_action.has_failed:
                code, reason = current_action.failure_reason
                result = current_action.result
                print("Go to pose failed: code=%s reason='%s' result=%s" % (code, reason, result))
                return

            h += 100
            numloop += 1

        print("Cozmo did the things!!!")


cozmo.run_program(search_and_stack)
